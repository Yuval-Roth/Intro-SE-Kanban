﻿namespace IntroSE.Kanban.Backend.DataAccessLayer
{
    public enum BoardColumnNames 
    {
        Backlog,
        Inprogress,
        Done
    }
}
