﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroSE.Kanban.Backend.DataAccessLayer
{
    public class DataLoader
    {
        private SQLExecuter executer;

        public UserDTO[] GetUsers()
        {
            throw new NotImplementedException();
        }
        public BoardDTO[] GetBoards()
        {
            throw new NotImplementedException();
        }
    }
}
