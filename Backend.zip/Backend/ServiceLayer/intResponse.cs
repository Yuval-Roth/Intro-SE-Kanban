﻿using System.Text.Json.Serialization;

namespace IntroSE.Kanban.Backend.ServiceLayer
{
    public class intResponse
    {

        [JsonInclude]
        public readonly int ReturnValue;

        public intResponse(int ReturnValue)
        {
            this.ReturnValue = ReturnValue;
        }

        public intResponse(string json)
        {
            Response<int> response = JsonController.BuildFromJson<Response<int>>(json);
            ReturnValue = response.returnValue;
        }
    }
    
}
