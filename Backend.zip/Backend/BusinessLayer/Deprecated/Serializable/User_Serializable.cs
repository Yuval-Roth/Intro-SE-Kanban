﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using IntroSE.Kanban.Backend.Utilities;



//namespace IntroSE.Kanban.Backend.BusinessLayer.Serializable
//{
//    [Serializable]
//    public sealed class User_Serializable
//    {
//        public CIString Email { get; set; }
//        public string Password { get; set; }
//    }
//}
