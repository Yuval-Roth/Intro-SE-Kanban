﻿//using System;
//using System.Collections.Generic;
//using IntroSE.Kanban.Backend.Utilities;
//namespace IntroSE.Kanban.Backend.BusinessLayer.Serializable
//{
//    [Serializable]
//    public sealed class Board_Serializable
//    {
//        public CIString Title { get; set; }
//        public LinkedList<Task>[] Columns { get; set; }
//        public int[] ColumnLimit { get; set; }
//        public Dictionary<int, TaskStates> TaskStateTracker { get; set; }
//    }
//}
