﻿namespace IntroSE.Kanban.Backend.BusinessLayer
{
    public enum TaskStates
    {
        backlog,
        inprogress,
        done
    }
}
